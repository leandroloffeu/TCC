const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('.'));

// Database setup
const db = new sqlite3.Database('database.db', (err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
    } else {
        console.log('Conectado ao banco de dados SQLite');
        createTables();
    }
});

function createTables() {
    db.serialize(() => {
        // Tabela de usuários
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            active INTEGER DEFAULT 1
        )`);

        // Tabela de ministérios
        db.run(`CREATE TABLE IF NOT EXISTS ministries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            leader_id INTEGER,
            active INTEGER DEFAULT 1,
            FOREIGN KEY (leader_id) REFERENCES users(id)
        )`);

        // Tabela de líderes de ministérios
        db.run(`CREATE TABLE IF NOT EXISTS ministry_leaders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ministry_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ministry_id) REFERENCES ministries(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )`);

        // Tabela de membros de ministérios
        db.run(`CREATE TABLE IF NOT EXISTS ministry_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ministry_id INTEGER,
            user_id INTEGER,
            active INTEGER DEFAULT 1,
            FOREIGN KEY (ministry_id) REFERENCES ministries(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )`);

        // Tabela de escalas
        db.run(`CREATE TABLE IF NOT EXISTS schedules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ministry_id INTEGER,
            date TEXT NOT NULL,
            FOREIGN KEY (ministry_id) REFERENCES ministries(id)
        )`);

        // Tabela de participantes da escala
        db.run(`CREATE TABLE IF NOT EXISTS schedule_participants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            schedule_id INTEGER,
            user_id INTEGER,
            role TEXT NOT NULL,
            FOREIGN KEY (schedule_id) REFERENCES schedules(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )`);

        // Adicionar coluna role se não existir
        db.run(`
            ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'
        `, (err) => {
            if (err && !err.message.includes('duplicate column name')) {
                console.error('Erro ao adicionar coluna role:', err);
            }
        });

        // Adicionar coluna active se não existir
        db.run(`
            ALTER TABLE users ADD COLUMN active INTEGER DEFAULT 1
        `, (err) => {
            if (err && !err.message.includes('duplicate column name')) {
                console.error('Erro ao adicionar coluna active:', err);
            }
        });

        // Adicionar coluna active se não existir
        db.run(`
            ALTER TABLE ministries ADD COLUMN active INTEGER DEFAULT 1
        `, (err) => {
            if (err && !err.message.includes('duplicate column name')) {
                console.error('Erro ao adicionar coluna active:', err);
            }
        });
    });
}

// Middleware de autenticação
const authenticateUser = (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        console.log('Auth Header:', authHeader); // Debug

        if (!authHeader) {
            return res.status(401).json({ error: 'Token não fornecido' });
        }

        const token = authHeader.split(' ')[1];
        console.log('Token:', token); // Debug

        if (!token) {
            return res.status(401).json({ error: 'Token inválido' });
        }

        // Verificar se o token é um objeto JSON válido
        let user;
        try {
            user = JSON.parse(token);
            console.log('Usuário decodificado:', user); // Debug
        } catch (error) {
            console.error('Erro ao decodificar token:', error);
            return res.status(401).json({ error: 'Token inválido: formato incorreto' });
        }

        if (!user || !user.id) {
            return res.status(401).json({ error: 'Token inválido: usuário não encontrado' });
        }

        req.user = user;
        next();
    } catch (error) {
        console.error('Erro na autenticação:', error);
        return res.status(401).json({ error: 'Token inválido' });
    }
};

// Middleware para verificar permissões
const checkPermission = (roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Não autorizado' });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Acesso negado' });
        }

        next();
    };
};

// API Routes
app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        // Validar o papel do usuário
        if (!role || !['admin', 'leader', 'user'].includes(role)) {
            return res.status(400).json({ error: 'Papel de usuário inválido. Deve ser admin, leader ou user.' });
        }

        // Verificar se o email já está cadastrado
        const existingUser = await new Promise((resolve, reject) => {
            db.get('SELECT id FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (existingUser) {
            return res.status(400).json({ error: 'Email já cadastrado' });
        }

        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);

        // Inserir novo usuário
        const userId = await new Promise((resolve, reject) => {
            db.run(
                'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
                [name, email, hashedPassword, role],
                function(err) {
                    if (err) reject(err);
                    resolve(this.lastID);
                }
            );
        });

        res.status(201).json({
            id: userId,
            name,
            email,
            role
        });
    } catch (error) {
        console.error('Erro ao registrar usuário:', error);
        res.status(500).json({ error: 'Erro ao registrar usuário' });
    }
});

app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    
    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
        if (err) {
            console.error('Erro ao fazer login:', err);
            return res.status(500).json({ error: 'Erro ao fazer login' });
        }
        
        if (!user) {
            return res.status(401).json({ error: 'Email ou senha incorretos' });
        }
        
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'Email ou senha incorretos' });
        }

        // Validar o papel do usuário
        if (!['admin', 'leader', 'user'].includes(user.role)) {
            console.error('Papel inválido:', user.role);
            return res.status(400).json({ error: 'Papel de usuário inválido' });
        }
        
        // Criar token com dados do usuário
        const token = JSON.stringify({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role
        });
        
        res.json({ 
            message: 'Login realizado com sucesso',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
    });
});

// Rota protegida para verificar autenticação
app.get('/api/check-auth', authenticateUser, (req, res) => {
    res.json({ user: req.user });
});

// Rota para obter os ministérios do usuário
app.get('/api/user-ministries', authenticateUser, async (req, res) => {
    try {
        const userId = req.user.id;
        const ministries = await db.all('SELECT * FROM ministries WHERE user_id = ?', [userId]);
        res.json(ministries);
    } catch (error) {
        console.error('Erro ao buscar ministérios:', error);
        res.status(500).json({ error: 'Erro ao buscar ministérios' });
    }
});

// Rota para adicionar um novo ministério
app.post('/api/add-ministry', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        console.log('Corpo da requisição:', req.body); // Debug
        const { name } = req.body;
        const userId = req.user.id;
        console.log('ID do usuário:', userId); // Debug

        if (!name) {
            return res.status(400).json({ error: 'Nome do ministério é obrigatório' });
        }

        db.run(
            'INSERT INTO ministries (name, user_id, active) VALUES (?, ?, ?)',
            [name, userId, 1],
            function(err) {
                if (err) {
                    console.error('Erro ao inserir ministério:', err);
                    return res.status(500).json({ error: 'Erro ao adicionar ministério' });
                }

                res.json({
                    id: this.lastID,
                    name,
                    active: 1
                });
            }
        );
    } catch (error) {
        console.error('Erro ao adicionar ministério:', error);
        res.status(500).json({ error: 'Erro ao adicionar ministério' });
    }
});

// Rota para alternar o status do ministério
app.post('/api/ministries/:id/toggle', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const ministryId = req.params.id;
        
        // Verificar se o ministério existe
        const ministry = await new Promise((resolve, reject) => {
            db.get('SELECT * FROM ministries WHERE id = ?', [ministryId], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!ministry) {
            return res.status(404).json({ error: 'Ministério não encontrado' });
        }

        // Alternar o status (0 para inativo, 1 para ativo)
        const newStatus = ministry.active ? 0 : 1;
        await new Promise((resolve, reject) => {
            db.run('UPDATE ministries SET active = ? WHERE id = ?', [newStatus, ministryId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.json({
            message: `Ministério ${newStatus ? 'ativado' : 'desativado'} com sucesso`,
            active: newStatus
        });
    } catch (error) {
        console.error('Erro ao alternar status do ministério:', error);
        res.status(500).json({ error: 'Erro ao alternar status do ministério' });
    }
});

// Rota para excluir ministério
app.post('/api/delete-ministry', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const { ministryId } = req.body;

        if (!ministryId) {
            return res.status(400).json({ error: 'ID do ministério é obrigatório' });
        }

        // Verificar se o ministério existe
        const ministry = await new Promise((resolve, reject) => {
            db.get('SELECT * FROM ministries WHERE id = ?', [ministryId], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!ministry) {
            return res.status(404).json({ error: 'Ministério não encontrado' });
        }

        // Excluir membros do ministério
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM ministry_members WHERE ministry_id = ?', [ministryId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        // Excluir o ministério
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM ministries WHERE id = ?', [ministryId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.json({ message: 'Ministério excluído com sucesso' });
    } catch (error) {
        console.error('Erro ao excluir ministério:', error);
        res.status(500).json({ error: 'Erro ao excluir ministério' });
    }
});

// Rota para criar ministério (apenas admin)
app.post('/api/ministries', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const { name, description, leaderId } = req.body;

        // Verificar se o líder existe e está ativo
        const leader = await new Promise((resolve, reject) => {
            db.get('SELECT id FROM users WHERE id = ? AND role = ? AND active = 1', [leaderId, 'leader'], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!leader) {
            return res.status(400).json({ error: 'Líder inválido ou inativo' });
        }

        const ministryId = await new Promise((resolve, reject) => {
            db.run(`
                INSERT INTO ministries (name, description, leader_id, active) 
                VALUES (?, ?, ?, 1)
            `, [name, description, leaderId], function(err) {
                if (err) reject(err);
                resolve(this.lastID);
            });
        });

        res.status(201).json({
            id: ministryId,
            name,
            description,
            leader_id: leaderId,
            active: 1
        });
    } catch (error) {
        console.error('Erro ao criar ministério:', error);
        res.status(500).json({ error: 'Erro ao criar ministério' });
    }
});

// Rota para adicionar membro ao ministério (apenas líder)
app.post('/api/ministries/:id/members', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const ministryId = req.params.id;
        const { name, email, password } = req.body;

        // Verificar se o ministério existe e está ativo
        const ministry = await new Promise((resolve, reject) => {
            db.get('SELECT leader_id FROM ministries WHERE id = ? AND active = 1', [ministryId], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!ministry) {
            return res.status(404).json({ error: 'Ministério não encontrado ou inativo' });
        }

        // Verificar se o usuário é líder deste ministério
        if (ministry.leader_id !== req.user.id) {
            return res.status(403).json({ error: 'Acesso não autorizado' });
        }

        // Verificar se o email já está cadastrado
        const existingUser = await new Promise((resolve, reject) => {
            db.get('SELECT id FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (existingUser) {
            return res.status(400).json({ error: 'Email já cadastrado' });
        }

        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);

        // Inserir novo usuário
        const userId = await new Promise((resolve, reject) => {
            db.run(`
                INSERT INTO users (name, email, password, role, active) 
                VALUES (?, ?, ?, 'user', 1)
            `, [name, email, hashedPassword], function(err) {
                if (err) reject(err);
                resolve(this.lastID);
            });
        });

        // Adicionar usuário ao ministério
        await new Promise((resolve, reject) => {
            db.run(`
                INSERT INTO ministry_members (ministry_id, user_id, active) 
                VALUES (?, ?, 1)
            `, [ministryId, userId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.status(201).json({
            id: userId,
            name,
            email,
            role: 'user'
        });
    } catch (error) {
        console.error('Erro ao cadastrar membro:', error);
        res.status(500).json({ error: 'Erro ao cadastrar membro' });
    }
});

// Rota para criar escala (apenas líder)
app.post('/api/schedules', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const { ministryId, date, participants } = req.body;
        const userId = req.user.id;

        console.log('Dados recebidos:', { ministryId, date, participants }); // Debug

        // Verificar se o ministério existe e está ativo
        const ministry = await new Promise((resolve, reject) => {
            db.get('SELECT id, name, leader_id FROM ministries WHERE id = ? AND active = 1', [ministryId], (err, row) => {
                if (err) {
                    console.error('Erro ao buscar ministério:', err); // Debug
                    reject(err);
                }
                console.log('Ministério encontrado:', row); // Debug
                resolve(row);
            });
        });

        if (!ministry) {
            console.log('Ministério não encontrado ou inativo'); // Debug
            return res.status(404).json({ error: 'Ministério não encontrado ou inativo' });
        }

        // Verificar se o usuário é líder deste ministério
        if (ministry.leader_id !== userId) {
            console.log('Usuário não é líder deste ministério'); // Debug
            return res.status(403).json({ error: 'Acesso não autorizado' });
        }

        // Inserir a escala
        const scheduleId = await new Promise((resolve, reject) => {
            db.run(`
                INSERT INTO schedules (ministry_id, date) 
                VALUES (?, ?)
            `, [ministryId, date], function(err) {
                if (err) {
                    console.error('Erro ao inserir escala:', err); // Debug
                    reject(err);
                }
                console.log('Escala criada com ID:', this.lastID); // Debug
                resolve(this.lastID);
            });
        });

        // Inserir os participantes
        for (const participant of participants) {
            await new Promise((resolve, reject) => {
                db.run(`
                    INSERT INTO schedule_participants (schedule_id, user_id, role) 
                    VALUES (?, ?, ?)
                `, [scheduleId, participant.member_id, participant.role], (err) => {
                    if (err) {
                        console.error('Erro ao inserir participante:', err); // Debug
                        reject(err);
                    }
                    resolve();
                });
            });
        }

        console.log('Participantes inseridos com sucesso'); // Debug

        // Buscar os dados completos da escala para retornar
        const schedule = await new Promise((resolve, reject) => {
            db.get(`
                SELECT s.*, m.name as ministry_name
                FROM schedules s
                JOIN ministries m ON s.ministry_id = m.id
                WHERE s.id = ?
            `, [scheduleId], (err, row) => {
                if (err) {
                    console.error('Erro ao buscar escala:', err); // Debug
                    reject(err);
                }
                console.log('Escala encontrada:', row); // Debug
                resolve(row);
            });
        });

        // Buscar os participantes
        const scheduleParticipants = await new Promise((resolve, reject) => {
            db.all(`
                SELECT u.id, u.name, sp.role
                FROM schedule_participants sp
                JOIN users u ON sp.user_id = u.id
                WHERE sp.schedule_id = ?
            `, [scheduleId], (err, rows) => {
                if (err) {
                    console.error('Erro ao buscar participantes:', err); // Debug
                    reject(err);
                }
                console.log('Participantes encontrados:', rows); // Debug
                resolve(rows);
            });
        });

        res.status(201).json({
            id: schedule.id,
            ministry_id: schedule.ministry_id,
            ministry_name: schedule.ministry_name,
            date: schedule.date,
            participants: scheduleParticipants
        });
    } catch (error) {
        console.error('Erro ao criar escala:', error);
        res.status(500).json({ error: 'Erro ao criar escala' });
    }
});

// Rota para obter escalas do usuário
app.get('/api/user-schedules', authenticateUser, async (req, res) => {
    try {
        const schedules = await new Promise((resolve, reject) => {
            db.all(`
                SELECT s.*, m.name as ministry_name,
                       GROUP_CONCAT(
                           json_object(
                               'id', u.id,
                               'name', u.name,
                               'role', sp.role
                           )
                       ) as participants_json
                FROM schedules s
                JOIN ministries m ON s.ministry_id = m.id
                JOIN schedule_participants sp ON s.id = sp.schedule_id
                JOIN users u ON sp.user_id = u.id
                WHERE sp.user_id = ?
                GROUP BY s.id
                ORDER BY s.date DESC
            `, [req.user.id], (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });

        // Processar participantes
        const processedSchedules = schedules.map(schedule => ({
            ...schedule,
            participants: JSON.parse(`[${schedule.participants_json}]`)
        }));

        res.json(processedSchedules);
    } catch (error) {
        console.error('Erro ao buscar escalas:', error);
        res.status(500).json({ error: 'Erro ao buscar escalas' });
    }
});

// Rota para obter ministérios do líder
app.get('/api/leader-ministries', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const ministries = await new Promise((resolve, reject) => {
            db.all(`
                SELECT m.*, u.name as leader_name 
                FROM ministries m
                LEFT JOIN users u ON m.leader_id = u.id
                WHERE m.leader_id = ? AND m.active = 1
                ORDER BY m.name
            `, [req.user.id], (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });
        
        res.json(ministries);
    } catch (error) {
        console.error('Erro ao buscar ministérios do líder:', error);
        res.status(500).json({ error: 'Erro ao buscar ministérios' });
    }
});

// Rota para obter membros de um ministério
app.get('/api/ministries/:id/members', authenticateUser, async (req, res) => {
    try {
        const ministryId = req.params.id;
        
        // Verificar se o ministério existe e está ativo
        const ministry = await new Promise((resolve, reject) => {
            db.get('SELECT leader_id FROM ministries WHERE id = ? AND active = 1', [ministryId], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!ministry) {
            return res.status(404).json({ error: 'Ministério não encontrado ou inativo' });
        }

        // Verificar se o usuário é líder deste ministério
        if (ministry.leader_id !== req.user.id) {
            return res.status(403).json({ error: 'Acesso não autorizado' });
        }

        const members = await new Promise((resolve, reject) => {
            db.all(`
                SELECT u.id, u.name, u.email
                FROM ministry_members mm
                JOIN users u ON mm.user_id = u.id
                WHERE mm.ministry_id = ? AND mm.active = 1 AND u.active = 1
                ORDER BY u.name
            `, [ministryId], (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });

        res.json(members);
    } catch (error) {
        console.error('Erro ao buscar membros:', error);
        res.status(500).json({ error: 'Erro ao buscar membros' });
    }
});

// Rota para obter escalas do líder
app.get('/api/leader-schedules', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        console.log('Buscando escalas para o líder:', req.user.id); // Debug
        const schedules = await new Promise((resolve, reject) => {
            db.all(`
                SELECT s.*, m.name as ministry_name,
                       json_group_array(
                           json_object(
                               'id', u.id,
                               'name', u.name,
                               'role', sp.role
                           )
                       ) as participants_json
                FROM schedules s
                JOIN ministries m ON s.ministry_id = m.id
                LEFT JOIN schedule_participants sp ON s.id = sp.schedule_id
                LEFT JOIN users u ON sp.user_id = u.id
                WHERE m.leader_id = ? AND m.active = 1
                GROUP BY s.id
                ORDER BY s.date DESC
            `, [req.user.id], (err, rows) => {
                if (err) {
                    console.error('Erro na query:', err); // Debug
                    reject(err);
                }
                console.log('Resultado da query:', rows); // Debug
                resolve(rows);
            });
        });

        console.log('Escalas encontradas:', schedules); // Debug

        // Processar participantes
        const processedSchedules = schedules.map(schedule => {
            try {
                return {
                    ...schedule,
                    participants: JSON.parse(schedule.participants_json || '[]')
                };
            } catch (error) {
                console.error('Erro ao processar participantes:', error);
                return {
                    ...schedule,
                    participants: []
                };
            }
        });

        console.log('Escalas processadas:', processedSchedules); // Debug
        res.json(processedSchedules);
    } catch (error) {
        console.error('Erro ao buscar escalas:', error);
        res.status(500).json({ error: 'Erro ao buscar escalas' });
    }
});

// Rota para verificar permissões do usuário
app.get('/api/check-permissions', authenticateUser, async (req, res) => {
    try {
        const user = req.user;
        const permissions = {
            canAccessAdmin: user.role === 'admin',
            canAccessLeader: user.role === 'admin' || user.role === 'leader',
            canAccessUser: true // Todos os usuários podem acessar a área de usuário
        };
        res.json(permissions);
    } catch (error) {
        console.error('Erro ao verificar permissões:', error);
        res.status(500).json({ error: 'Erro ao verificar permissões' });
    }
});

// Rota para cadastrar líder (apenas admin)
app.post('/api/register-leader', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Verificar se o email já está cadastrado
        const existingUser = await new Promise((resolve, reject) => {
            db.get('SELECT id FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (existingUser) {
            return res.status(400).json({ error: 'Email já cadastrado' });
        }

        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);

        // Inserir novo líder
        const userId = await new Promise((resolve, reject) => {
            db.run(
                'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
                [name, email, hashedPassword, 'leader'],
                function(err) {
                    if (err) reject(err);
                    resolve(this.lastID);
                }
            );
        });

        res.status(201).json({
            id: userId,
            name,
            email,
            role: 'leader'
        });
    } catch (error) {
        console.error('Erro ao cadastrar líder:', error);
        res.status(500).json({ error: 'Erro ao cadastrar líder' });
    }
});

// Rota para cadastrar usuário (apenas líder)
app.post('/api/register-user', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const { name, email, password, ministryId } = req.body;

        // Verificar se o email já está cadastrado
        const existingUser = await new Promise((resolve, reject) => {
            db.get('SELECT id FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (existingUser) {
            return res.status(400).json({ error: 'Email já cadastrado' });
        }

        // Verificar se o líder tem permissão para adicionar usuários a este ministério
        const isLeader = await new Promise((resolve, reject) => {
            db.get(
                'SELECT 1 FROM ministry_leaders WHERE ministry_id = ? AND user_id = ?',
                [ministryId, req.user.id],
                (err, row) => {
                    if (err) reject(err);
                    resolve(!!row);
                }
            );
        });

        if (!isLeader) {
            return res.status(403).json({ error: 'Você não é líder deste ministério' });
        }

        // Hash da senha
        const hashedPassword = await bcrypt.hash(password, 10);

        // Inserir novo usuário
        const userId = await new Promise((resolve, reject) => {
            db.run(
                'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
                [name, email, hashedPassword, 'user'],
                function(err) {
                    if (err) reject(err);
                    resolve(this.lastID);
                }
            );
        });

        // Adicionar usuário ao ministério
        await new Promise((resolve, reject) => {
            db.run(
                'INSERT INTO ministry_members (ministry_id, user_id) VALUES (?, ?)',
                [ministryId, userId],
                (err) => {
                    if (err) reject(err);
                    resolve();
                }
            );
        });

        res.status(201).json({
            id: userId,
            name,
            email,
            role: 'user',
            ministry_id: ministryId
        });
    } catch (error) {
        console.error('Erro ao cadastrar usuário:', error);
        res.status(500).json({ error: 'Erro ao cadastrar usuário' });
    }
});

// Rota para obter todos os líderes (apenas admin)
app.get('/api/leaders', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const leaders = await new Promise((resolve, reject) => {
            db.all(`
                SELECT id, name, email, active 
                FROM users 
                WHERE role = 'leader'
                ORDER BY name
            `, (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });
        
        res.json(leaders);
    } catch (error) {
        console.error('Erro ao buscar líderes:', error);
        res.status(500).json({ error: 'Erro ao buscar líderes' });
    }
});

// Rota para obter todos os ministérios (apenas admin)
app.get('/api/ministries', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const ministries = await new Promise((resolve, reject) => {
            db.all(`
                SELECT m.*, u.name as leader_name, u.email as leader_email 
                FROM ministries m
                LEFT JOIN users u ON m.leader_id = u.id
                ORDER BY m.name
            `, (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });
        
        // Adicionar contagem de membros ativos para cada ministério
        for (let ministry of ministries) {
            const memberCount = await new Promise((resolve, reject) => {
                db.get(`
                    SELECT COUNT(*) as count 
                    FROM ministry_members mm
                    JOIN users u ON mm.user_id = u.id
                    WHERE mm.ministry_id = ? AND mm.active = 1 AND u.active = 1
                `, [ministry.id], (err, row) => {
                    if (err) reject(err);
                    resolve(row ? row.count : 0);
                });
            });
            ministry.active_members = memberCount;
        }
        
        res.json(ministries);
    } catch (error) {
        console.error('Erro ao buscar ministérios:', error);
        res.status(500).json({ error: 'Erro ao buscar ministérios' });
    }
});

// Rota para desativar/ativar líder
app.post('/api/leaders/:id/toggle', authenticateUser, checkPermission(['admin']), async (req, res) => {
    try {
        const leaderId = req.params.id;
        
        // Verificar se o líder existe
        const leader = await new Promise((resolve, reject) => {
            db.get('SELECT active FROM users WHERE id = ? AND role = ?', [leaderId, 'leader'], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!leader) {
            return res.status(404).json({ error: 'Líder não encontrado' });
        }

        // Alternar status
        const newStatus = leader.active === 1 ? 0 : 1;
        await new Promise((resolve, reject) => {
            db.run('UPDATE users SET active = ? WHERE id = ?', [newStatus, leaderId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.json({ 
            message: `Líder ${newStatus === 1 ? 'ativado' : 'desativado'} com sucesso`,
            active: newStatus 
        });
    } catch (error) {
        console.error('Erro ao alternar status do líder:', error);
        res.status(500).json({ error: 'Erro ao alternar status do líder' });
    }
});

// Rota para obter usuários comuns
app.get('/api/users', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const users = await new Promise((resolve, reject) => {
            db.all(`
                SELECT id, name, email, role 
                FROM users 
                WHERE active = 1
                ORDER BY name
            `, (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });
        
        res.json(users);
    } catch (error) {
        console.error('Erro ao buscar usuários:', error);
        res.status(500).json({ error: 'Erro ao buscar usuários' });
    }
});

// Rota para debug - verificar todas as escalas
app.get('/api/debug/schedules', authenticateUser, async (req, res) => {
    try {
        const schedules = await new Promise((resolve, reject) => {
            db.all(`
                SELECT s.*, m.name as ministry_name, m.leader_id,
                       json_group_array(
                           json_object(
                               'id', u.id,
                               'name', u.name,
                               'role', sp.role
                           )
                       ) as participants_json
                FROM schedules s
                JOIN ministries m ON s.ministry_id = m.id
                LEFT JOIN schedule_participants sp ON s.id = sp.schedule_id
                LEFT JOIN users u ON sp.user_id = u.id
                GROUP BY s.id
                ORDER BY s.date DESC
            `, (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            });
        });

        // Processar participantes
        const processedSchedules = schedules.map(schedule => {
            try {
                return {
                    ...schedule,
                    participants: JSON.parse(schedule.participants_json || '[]')
                };
            } catch (error) {
                console.error('Erro ao processar participantes:', error);
                return {
                    ...schedule,
                    participants: []
                };
            }
        });

        res.json(processedSchedules);
    } catch (error) {
        console.error('Erro ao buscar escalas:', error);
        res.status(500).json({ error: 'Erro ao buscar escalas' });
    }
});

// Rota para debug - verificar token
app.get('/api/debug/token', authenticateUser, (req, res) => {
    res.json({
        token: req.headers.authorization,
        user: req.user
    });
});

// Rota para excluir escala
app.delete('/api/schedules/:id', authenticateUser, checkPermission(['leader']), async (req, res) => {
    try {
        const scheduleId = req.params.id;
        
        // Verificar se a escala existe e pertence ao líder
        const schedule = await new Promise((resolve, reject) => {
            db.get(`
                SELECT s.*, m.leader_id 
                FROM schedules s
                JOIN ministries m ON s.ministry_id = m.id
                WHERE s.id = ? AND m.leader_id = ?
            `, [scheduleId, req.user.id], (err, row) => {
                if (err) reject(err);
                resolve(row);
            });
        });

        if (!schedule) {
            return res.status(404).json({ error: 'Escala não encontrada ou você não tem permissão para excluí-la' });
        }

        // Excluir participantes da escala
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM schedule_participants WHERE schedule_id = ?', [scheduleId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        // Excluir a escala
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM schedules WHERE id = ?', [scheduleId], (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.json({ message: 'Escala excluída com sucesso' });
    } catch (error) {
        console.error('Erro ao excluir escala:', error);
        res.status(500).json({ error: 'Erro ao excluir escala' });
    }
});

// Serve static files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
}); 